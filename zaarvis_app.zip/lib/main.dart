
import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() => runApp(ZaarvisApp());

class ZaarvisApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Zaarvis AI',
      theme: ThemeData.dark(),
      home: ZaarvisHome(),
    );
  }
}

class ZaarvisHome extends StatefulWidget {
  @override
  _ZaarvisHomeState createState() => _ZaarvisHomeState();
}

class _ZaarvisHomeState extends State<ZaarvisHome> {
  final FlutterTts tts = FlutterTts();

  Future _speak() async {
    await tts.setLanguage("en-US");
    await tts.setPitch(1.0);
    await tts.speak("Hello Shojib Bhai, how can I help you today?");
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Zaarvis AI')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.mic, size: 100, color: Colors.blueAccent),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _speak,
              child: Text('Tap to Talk'),
            ),
          ],
        ),
      ),
    );
  }
}
